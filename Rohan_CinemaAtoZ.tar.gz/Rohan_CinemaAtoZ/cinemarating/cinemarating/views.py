from django.shortcuts import render
from movies import models
from movies.models import Movie
from movies.models import Watchlist
from django.shortcuts import get_object_or_404
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth.models import User

# Create your views here.
def display(request):
	st=Movie.objects.all() # Collect all records from table 
	return render(request,'display.html',{'st':st})
def watchlist_add(request, product_id):
    item_to_save = get_object_or_404(Movie, pk=product_id)
    # Check if the item already exists in that user watchlist
    if Watchlist.objects.filter(user=request.user, item=product_id).exists():
        messages.add_message(request, messages.ERROR, "You already have it in your watchlist.")
        return HttpResponseRedirect(reverse("auctions:index"))
    # Get the user watchlist or create it if it doesn't exists
    user_list, created = Watchlist.objects.get_or_create(user=request.user)
    # Add the item through the ManyToManyField (Watchlist => item)
    user_list.item.add(item_to_save)
    messages.add_message(request, messages.SUCCESS, "Successfully added to your watchlist")
    return render(request, "watchlist.html")
