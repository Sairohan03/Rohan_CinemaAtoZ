from datetime import timezone
import re
import time
from django.core.management.base import BaseCommand
from urllib.request import urlopen
from bs4 import BeautifulSoup
import json
import requests
from movies import models
from movies.models import Movie
from rotten_tomatoes_scraper.rt_scraper import MovieScraper
class Command(BaseCommand):
    help = "collect Movies"
    # define logic of command
    def handle(self, *args, **options):
        # collect html
        connected = False
        
            
        url = 'http://www.imdb.com/chart/top'
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        movies = soup.select('td.titleColumn')
        crew = [a.attrs.get('title') for a in soup.select('td.titleColumn a')]
        ratings = [b.attrs.get('data-value') for b in soup.select('td.posterColumn span[name=ir]')]
            
 
 
 
# create a empty list for storing
# movie information
        list = []
 
# Iterating over movies to extract
# each movie's details
        for index in range(0, int(len(movies)/4)):
     
    # Separating movie into: 'place',
    # 'title', 'year'
            movie_string = movies[index].get_text()
            movie = (' '.join(movie_string.split()).replace('.', ''))
            movie_title = movie[len(str(index))+1:-7]
            year = re.search('\((.*?)\)', movie_string).group(1)
            place = movie[:len(str(index))-(len(movie))]
            movie_scraper = MovieScraper(movie_title=movie_title)
            movie_scraper.extract_metadata()
            x = movie_scraper.metadata
            data = {"place": place,"movie_title": movie_title,"rating": ratings[index],"rotten": x['Score_Rotten'],"year": year,"star_cast": crew[index],"genre":x['Genre'],}
            list.append(data)
        
                # save in db
            Movie.objects.create(
                title = movie_title,
                Ratingimdb = ratings[index],
                RatingRt  = x['Score_Rotten'],
                RatingMc = x['Score_Rotten'],
                Plot  = movie_title,
                Cast = crew[index],
                Genre = x['Genre'],
                )
            print('%s added' % (movie_title,))
            #    print('%s already exists' % (movie_title,))
        url = 'http://www.imdb.com/chart/top'
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        movies = soup.select('td.titleColumn')
        crew = [a.attrs.get('title') for a in soup.select('td.titleColumn a')]
        ratings = [b.attrs.get('data-value') for b in soup.select('td.posterColumn span[name=ir]')]
        for index in range(int(len(movies)/4), int(len(movies)/2)):
     
    # Separating movie into: 'place',
    # 'title', 'year'
            movie_string = movies[index].get_text()
            movie = (' '.join(movie_string.split()).replace('.', ''))
            movie_title = movie[len(str(index))+1:-7]
            year = re.search('\((.*?)\)', movie_string).group(1)
            place = movie[:len(str(index))-(len(movie))]
            movie_scraper = MovieScraper(movie_title=movie_title)
            movie_scraper.extract_metadata()
            x = movie_scraper.metadata
            data = {"place": place,"movie_title": movie_title,"rating": ratings[index],"rotten": x['Score_Rotten'],"year": year,"star_cast": crew[index],"genre":x['Genre'],}
            list.append(data)
        
                # save in db
            Movie.objects.create(
                title = movie_title,
                Ratingimdb = ratings[index],
                RatingRt  = x['Score_Rotten'],
                RatingMc = x['Score_Rotten'],
                Plot  = movie_title,
                Cast = crew[index],
                Genre = x['Genre'],
                )
            print('%s added' % (movie_title,))
        url = 'http://www.imdb.com/chart/top'
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        movies = soup.select('td.titleColumn')
        crew = [a.attrs.get('title') for a in soup.select('td.titleColumn a')]
        ratings = [b.attrs.get('data-value') for b in soup.select('td.posterColumn span[name=ir]')]
        for index in range(int(len(movies)/2), 3*int(len(movies)/4)):
     
    # Separating movie into: 'place',
    # 'title', 'year'
            movie_string = movies[index].get_text()
            movie = (' '.join(movie_string.split()).replace('.', ''))
            movie_title = movie[len(str(index))+1:-7]
            year = re.search('\((.*?)\)', movie_string).group(1)
            place = movie[:len(str(index))-(len(movie))]
            movie_scraper = MovieScraper(movie_title=movie_title)
            movie_scraper.extract_metadata()
            x = movie_scraper.metadata
            data = {"place": place,"movie_title": movie_title,"rating": ratings[index],"rotten": x['Score_Rotten'],"year": year,"star_cast": crew[index],"genre":x['Genre'],}
            list.append(data)
        
                # save in db
            Movie.objects.create(
                title = movie_title,
                Ratingimdb = ratings[index],
                RatingRt  = x['Score_Rotten'],
                RatingMc = x['Score_Rotten'],
                Plot  = movie_title,
                Cast = crew[index],
                Genre = x['Genre'],
                )
            print('%s added' % (movie_title,))
        url = 'http://www.imdb.com/chart/top'
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        movies = soup.select('td.titleColumn')
        crew = [a.attrs.get('title') for a in soup.select('td.titleColumn a')]
        ratings = [b.attrs.get('data-value') for b in soup.select('td.posterColumn span[name=ir]')]
        for index in range(3*int(len(movies)/4), int(len(movies))):
     
    # Separating movie into: 'place',
    # 'title', 'year'
            movie_string = movies[index].get_text()
            movie = (' '.join(movie_string.split()).replace('.', ''))
            movie_title = movie[len(str(index))+1:-7]
            year = re.search('\((.*?)\)', movie_string).group(1)
            place = movie[:len(str(index))-(len(movie))]
            movie_scraper = MovieScraper(movie_title=movie_title)
            movie_scraper.extract_metadata()
            x = movie_scraper.metadata
            data = {"place": place,"movie_title": movie_title,"rating": ratings[index],"rotten": x['Score_Rotten'],"year": year,"star_cast": crew[index],"genre":x['Genre'],}
            list.append(data)
        
                # save in db
            Movie.objects.create(
                title = movie_title,
                Ratingimdb = ratings[index],
                RatingRt  = x['Score_Rotten'],
                RatingMc = x['Score_Rotten'],
                Plot  = movie_title,
                Cast = crew[index],
                Genre = x['Genre'],
                )
            print('%s added' % (movie_title,))
        self.stdout.write( 'job complete' )