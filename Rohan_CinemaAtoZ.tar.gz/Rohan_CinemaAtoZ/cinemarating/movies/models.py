#from django.db import models

# Create your models here.
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
#from django.contrib.auth.models import AbstractUser
#class User(AbstractUser):
#    pass
class Movie(models.Model):
    #url = models.CharField(max_length=250, unique=True)
    title = models.CharField(max_length=250)
    Ratingimdb = models.CharField(max_length=250)
    RatingRt  = models.CharField(max_length=250)
    RatingMc = models.CharField(max_length=250)
    Plot  = models.CharField(max_length=250)
    Cast = models.CharField(max_length=250)
    Genre = models.CharField(max_length=250)
    created_date = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.title
    class Meta:
        ordering = ['title']
    def __str__(self):
        return f"Item ID: {self.id} | Title: {self.title}"
    class Admin:
        pass
    def __str__(self):
        return f"id:{self.id}","Name: {self.title}, Rating: {self.Ratingimdb}, Cast: {self.Cast} "
class Watchlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    item = models.ForeignKey(Movie, on_delete=models.CASCADE, null=True)
    def __str__(self):
        return f"{self.user}'s WatchList"
    