1)convert to virtual env in cinema folder
2)open the folder cinema rating
3)run python manage.py scrape to scrape the data from imdb,rotten tomatoes
4)run python manage.py runserver
